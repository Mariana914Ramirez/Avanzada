/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import dao.userDAO;
import entity.User;

/**
 *
 * @author jonav
 */
@ManagedBean (name = "inUser" )
@SessionScoped
public class userController {
    private String nombreUsuario;
    private String password;
    
    public String validaLogin() throws Exception
    {
        userDAO USER = new userDAO();
        User u = USER.validarUsuario(nombreUsuario, password);
        
        if(u!=null)
        {
            nombreUsuario = u.getUser();
            return "principal";
        }
        else
            return "index";
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }



    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
