/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import entity.User;
import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author jonav
 */
public class userDAO {
    private EntityManagerFactory emf;

    public userDAO() {
        emf = Persistence.createEntityManagerFactory("LoginJsfJpaPU");
    }
    
    public User validarUsuario(String usuario, String password)
    {
        User user;
        EntityManager em = emf.createEntityManager();
        String sql = "SELECT u FROM User u WHERE u.user = :user AND u.password = :password";
        
        Query query = em.createQuery(sql);
        query.setParameter("user", usuario);
        query.setParameter("password", password);
        
        user = (User) query.getSingleResult();   
        return user;
    }
    
    
    
    
}
