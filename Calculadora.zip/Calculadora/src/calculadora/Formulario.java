/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author BLUE_LIGHT
 */
public class Formulario extends JFrame implements ActionListener{
    
    boolean primer=false;
    String operacion="";
    String operacionTemp;
    int numero=0, numeroTemp=0;
    int cantOperaciones=0, cantImaginarios=0, cantParentesis;
    boolean negativo=false;
    boolean suma=false, resta=false, mul=false, div=false;
    int [] array = new int [6];
    
    
    private JButton B1;
    private JButton B2;
    private JButton B3;
    private JButton B4;
    private JButton B5;
    private JButton B6;
    private JButton B7;
    private JButton B8;
    private JButton B9;
    private JButton B0;
    private JButton Bi;
    private JButton BP1;
    private JButton BP2;
    private JButton B;
    private JButton BMas;
    private JButton BNull;
    private JButton BMenos;
    private JButton BMul;
    private JButton BDiv;
    private JLabel texto;
    
    public Formulario()
    {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Calculadora");
        this.getContentPane().setBackground(new Color(42,56,59));
        
        
        B1=new JButton("1");
        B1.setBackground(new Color(219,219,92));
        B1.setFont(new Font("Consolas", Font.BOLD, 20));
        B1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B1.addActionListener((ActionListener) this);
        
        B2=new JButton("2");
        B2.setBackground(new Color(219,219,92));
        B2.setFont(new Font("Consolas", Font.BOLD, 20));
        B2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B2.addActionListener((ActionListener) this);
        
        B3=new JButton("3");
        B3.setBackground(new Color(219,219,92));
        B3.setFont(new Font("Consolas", Font.BOLD, 20));
        B3.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B3.addActionListener((ActionListener) this);
        
        B4=new JButton("4");
        B4.setBackground(new Color(219,219,92));
        B4.setFont(new Font("Consolas", Font.BOLD, 20));
        B4.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B4.addActionListener((ActionListener) this);
        
        B5=new JButton("5");
        B5.setBackground(new Color(219,219,92));
        B5.setFont(new Font("Consolas", Font.BOLD, 20));
        B5.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B5.addActionListener((ActionListener) this);
        
        B6=new JButton("6");
        B6.setBackground(new Color(219,219,92));
        B6.setFont(new Font("Consolas", Font.BOLD, 20));
        B6.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B6.addActionListener((ActionListener) this);
        
        B7=new JButton("7");
        B7.setBackground(new Color(219,219,92));
        B7.setFont(new Font("Consolas", Font.BOLD, 20));
        B7.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B7.addActionListener((ActionListener) this);
        
        B8=new JButton("8");
        B8.setBackground(new Color(219,219,92));
        B8.setFont(new Font("Consolas", Font.BOLD, 20));
        B8.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B8.addActionListener((ActionListener) this);
        
        B9=new JButton("9");
        B9.setBackground(new Color(219,219,92));
        B9.setFont(new Font("Consolas", Font.BOLD, 20));
        B9.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B9.addActionListener((ActionListener) this);
        
        B0=new JButton("0");
        B0.setBackground(new Color(219,219,92));
        B0.setFont(new Font("Consolas", Font.BOLD, 20));
        B0.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B0.addActionListener((ActionListener) this);
        
        Bi=new JButton("i");
        Bi.setBackground(new Color(0,163,24));
        Bi.setFont(new Font("Consolas", Font.BOLD, 20));
        Bi.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        Bi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"i";
                texto.setText(operacion);
                if(numero==0)
                {
                    numero=1;
                }
                cantImaginarios++;
                if(cantImaginarios==1){
                    if(negativo){
                        numero=numero*(-1);
                    }
                    array[2]=numero;
                }
                else if(cantImaginarios==2){
                    if(negativo){
                        numero=numero*(-1);
                    }
                    array[5]=numero;
                }
                negativo=false;
            }
        });
        
        BP1=new JButton("(");
        BP1.setBackground(new Color(78,183,171));
        BP1.setFont(new Font("Consolas", Font.BOLD, 20));
        BP1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BP1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"(";
                texto.setText(operacion); 
                numero=0;
                cantParentesis++;
            }
        });
        
        BP2=new JButton(")");
        BP2.setBackground(new Color(78,183,171));
        BP2.setFont(new Font("Consolas", Font.BOLD, 20));
        BP2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BP2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+")";
                texto.setText(operacion); 
                numero=0;
                cantParentesis++;
            }
        });
        
        B=new JButton("=");
        B.setBackground(new Color(0,163,24));
        B.setFont(new Font("Consolas", Font.BOLD, 20));
        B.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        B.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                if(cantOperaciones==3&&cantImaginarios==2&&cantParentesis==4)
                {
                    float op1, op2, op3, op4;
                    String signo="+";
                    if(suma)
                    {
                        op1=array[0]+array[3];
                        op2=array[2]+array[5];
                        operacionTemp=String.valueOf(op1);
                        operacion=operacionTemp;
                        operacionTemp=String.valueOf(op2);
                        if(op2<0){signo="";}
                        operacion=operacion+signo+operacionTemp+"i";
                        texto.setText(operacion);
                    }
                    else if(resta)
                    {
                        op1=array[0]+array[3];
                        op2=array[2]-array[5];
                        operacionTemp=String.valueOf(op1);
                        operacion=operacionTemp;
                        operacionTemp=String.valueOf(op2);
                        if(op2<0){signo="";}
                        operacion=operacion+signo+operacionTemp+"i";
                        texto.setText(operacion);
                    }
                    else if(mul)
                    {
                        op1=array[0]*array[3];
                        op2=array[0]*array[5];
                        op3=array[2]*array[3];
                        op4=(array[2]*array[5])*(-1);
                        
                        op1=op1+op4;
                        op2=op2+op3;
                        operacionTemp=String.valueOf(op1);
                        operacion=operacionTemp;
                        operacionTemp=String.valueOf(op2);
                        if(op2<0){signo="";}
                        operacion=operacion+signo+operacionTemp+"i";
                        texto.setText(operacion);
                    }
                    else if(div)
                    {
                        float op5, op6;
                        op1=array[0]*array[3];
                        op2=array[0]*(array[5]*(-1));
                        op3=array[2]*array[3];
                        op4=array[2]*array[5];
                        
                        op5=array[3]*array[3];
                        op6=array[5]*array[5];
                        
                        op5=op5+op6;
                        op3=op2+op3;
                        op4=op4+op1;
                        
                        op1=op4/op5;
                        op2=op3/op5;
                        operacionTemp=String.valueOf(op1);
                        operacion=operacionTemp;
                        operacionTemp=String.valueOf(op2);
                        if(op2<0){signo="";}
                        operacion=operacion+signo+operacionTemp+"i";
                        texto.setText(operacion);
                    }
                }
                else{
                    operacion="Sintaxis error";
                    texto.setText(operacion);
                }
            }
        });
        
        BMas=new JButton("+");
        BMas.setBackground(new Color(117,53,255));
        BMas.setFont(new Font("Consolas", Font.BOLD, 20));
        BMas.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BMas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"+";
                texto.setText(operacion);
                if(primer)
                {
                    cantOperaciones++;
                    if(cantOperaciones==2)
                    {
                        suma=true;
                    }
                    else
                    {
                        if(cantOperaciones==1){
                            if(negativo){
                                numero=numero*(-1);
                            }
                            array[0]=numero;
                            array[1]=0;
                        }
                        else if(cantOperaciones==3){
                            if(negativo==true){
                                numero=numero*(-1);
                            }
                            array[3]=numero;
                            array[4]=0;
                        }
                    }
                    primer=false;
                }
                negativo=false;
                numero=0;
            }
        });
        
        BMenos=new JButton("-");
        BMenos.setBackground(new Color(117,53,255));
        BMenos.setFont(new Font("Consolas", Font.BOLD, 20));
        BMenos.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BMenos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"-";
                texto.setText(operacion);
                if(primer)
                {
                    cantOperaciones++;
                    if(cantOperaciones==2)
                    {
                        resta=true;
                    }
                    else
                    {
                        if(cantOperaciones==1){
                            if(negativo==true){
                                numero=numero*(-1);
                            }
                            array[0]=numero;
                            array[1]=1;
                        }
                        else if(cantOperaciones==3){
                            if(negativo==true){
                                numero=numero*(-1);
                            }
                            array[3]=numero;
                            array[4]=1;
                        }
                    }
                    primer=false;
                }
                negativo=true;
                numero=0;
            }
        });
        
        BMul=new JButton("*");
        BMul.setBackground(new Color(117,53,255));
        BMul.setFont(new Font("Consolas", Font.BOLD, 20));
        BMul.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BMul.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"*";
                texto.setText(operacion);
                cantOperaciones++;
                if(cantOperaciones==2)
                {
                    mul=true;
                }
                primer=false;
            }
        });
        
        BDiv=new JButton("/");
        BDiv.setBackground(new Color(117,53,255));
        BDiv.setFont(new Font("Consolas", Font.BOLD, 20));
        BDiv.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BDiv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion=operacion+"/";
                texto.setText(operacion);
                cantOperaciones++;
                if(cantOperaciones==2)
                {
                    div=true;
                }
                primer=false;
            }
        });
        
        BNull=new JButton("DEL");
        BNull.setBackground(new Color(209,81,96));
        BNull.setFont(new Font("Consolas", Font.BOLD, 20));
        BNull.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        BNull.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {   
                operacion="";
                texto.setText(operacion);
                numero=0;
                primer=false;
                negativo=false;
                suma=false;
                resta=false;
                mul=false;
                div=false;
                cantOperaciones=0;
                cantImaginarios=0;
                cantParentesis=0;
            }
        });
        
        
        texto=new JLabel("Hola", JLabel.CENTER);
        texto.setFont(new Font("Consolas", Font.BOLD, 20));
        texto.setOpaque(true);
        texto.setBackground(Color.WHITE);
        texto.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        
        
        
        GroupLayout datos=new GroupLayout(this.getContentPane());
        
        datos.setHorizontalGroup(
                datos.createParallelGroup()
                    .addComponent(texto, 240, 240, 1200)
                    .addGroup(datos.createSequentialGroup().addComponent(B1, 80, 80, 1200)
                                                           .addComponent(B2, 80, 80, 1200)
                                                           .addComponent(B3, 80, 80, 1200))
                    .addGroup(datos.createSequentialGroup().addComponent(B4, 80, 80, 1200)
                                                           .addComponent(B5, 80, 80, 1200)
                                                           .addComponent(B6, 80, 80, 1200))
                    .addGroup(datos.createSequentialGroup().addComponent(B7, 80, 80, 1200)
                                                           .addComponent(B8, 80, 80, 1200)
                                                           .addComponent(B9, 80, 80, 1200))
                    .addGroup(datos.createSequentialGroup().addComponent(Bi, 80, 80, 1200)
                                                           .addComponent(B0, 80, 80, 1200)
                                                           .addComponent(B, 80, 80, 1200))
                    .addGroup(datos.createSequentialGroup().addComponent(BP1, 80, 80, 1200)
                                                           .addComponent(BNull, 80, 80, 1200)
                                                           .addComponent(BP2, 80, 80, 1200))
                    .addGroup(datos.createSequentialGroup().addComponent(BMas, 10, 50, 1200)
                                                           .addComponent(BMenos, 10, 50, 1200)
                                                           .addComponent(BMul, 10, 50, 1200)
                                                           .addComponent(BDiv, 10, 50, 1200))
        );
        
        
        datos.setVerticalGroup(
                datos.createSequentialGroup()
                    .addComponent(texto, 10, 40, 1200)
                    .addGroup(datos.createParallelGroup().addComponent(B1, 10, 40, 80)
                                                           .addComponent(B2, 10, 40, 80)
                                                           .addComponent(B3, 10, 40, 80))
                    .addGroup(datos.createParallelGroup().addComponent(B4, 10, 40, 80)
                                                           .addComponent(B5, 10, 40, 80)
                                                           .addComponent(B6, 10, 40, 80))
                    .addGroup(datos.createParallelGroup().addComponent(B7, 10, 40, 80)
                                                           .addComponent(B8, 10, 40, 80)
                                                           .addComponent(B9, 10, 40, 80))
                    .addGroup(datos.createParallelGroup().addComponent(Bi, 10, 40, 80)
                                                           .addComponent(B0, 10, 40, 80)
                                                           .addComponent(B, 10, 40, 80))
                    .addGroup(datos.createParallelGroup().addComponent(BP1, 10, 40, 80)
                                                           .addComponent(BNull, 10, 40, 80)
                                                           .addComponent(BP2, 10, 40, 80))
                    .addGroup(datos.createParallelGroup().addComponent(BMas, 10, 40, 80)
                                                           .addComponent(BMenos, 10, 40, 80)
                                                           .addComponent(BMul, 10, 40, 80)
                                                           .addComponent(BDiv, 10, 40, 80))
        );
        datos.setAutoCreateContainerGaps(true);
        datos.setAutoCreateGaps(true);
        setLayout(datos);
        pack();
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==B1)
            operacionTemp=B1.getText().toUpperCase();
        else if(e.getSource()==B2)
            operacionTemp=B2.getText().toUpperCase();
        else if(e.getSource()==B3)
            operacionTemp=B3.getText().toUpperCase();
        else if(e.getSource()==B4)
            operacionTemp=B4.getText().toUpperCase();
        else if(e.getSource()==B5)
            operacionTemp=B5.getText().toUpperCase();
        else if(e.getSource()==B6)
            operacionTemp=B6.getText().toUpperCase();
        else if(e.getSource()==B7)
            operacionTemp=B7.getText().toUpperCase();
        else if(e.getSource()==B8)
            operacionTemp=B8.getText().toUpperCase();
        else if(e.getSource()==B9)
            operacionTemp=B9.getText().toUpperCase();
        else if(e.getSource()==B0)
            operacionTemp=B0.getText().toUpperCase();
            
        if(!primer){
            primer=true;
            operacion=operacion+operacionTemp;
            texto.setText(operacion);
            numero=Integer.parseInt(operacionTemp);
        }
        else{ 
            numeroTemp=Integer.parseInt(operacionTemp);
            operacion=operacion+operacionTemp;
            texto.setText(operacion);
            numero=(numero*10)+numeroTemp;
        }
    }
}
