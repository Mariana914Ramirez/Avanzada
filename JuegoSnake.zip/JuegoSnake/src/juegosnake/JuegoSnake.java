/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegosnake;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author BLUE_LIGHT
 */
public class JuegoSnake {
    
    private JLabel texto;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        JFrame frm=new JFrame("Juego Snake");
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.add(new MiPanel());
        frm.pack();
        
        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
        //Panelcx();
        while(true){
            frm.repaint();
            Thread.sleep(200);
        }
    }
    
    
   /* public void Panelcx()
    {
        JPanel panel=new JPanel();
        
        texto=new JLabel("Puntaje: ", JLabel.CENTER);
        texto.setFont(new Font("Consolas", Font.BOLD, 20));
        texto.setBounds(20, 20, 50, 100);
        texto.setForeground(Color.white);
        panel.add(texto);
        this.getContentPane().add(panel);
    }*/
    
}
