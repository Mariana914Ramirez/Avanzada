/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegosnake;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author BLUE_LIGHT
 */
public class MiPanel extends JPanel implements KeyListener{
    private Juego serpiente;
    private JLabel texto;
    private JButton boton1;
    
    public MiPanel(){
        serpiente = new Juego();
        setFocusable(true);
        addKeyListener(this);
        this.setLayout(null);
        
        texto=new JLabel("Puntaje: ", JLabel.CENTER);
        texto.setBounds(0, 0, 1000, 100);
        texto.setFont(new Font("Consolas", Font.BOLD, 30));
        
        texto.setForeground(Color.BLACK);
        texto.setOpaque(true);
        texto.setBackground(new Color(170,103,247));
        this.add(texto);
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
        g.setColor(new Color(103,255,86));
        g.fillRect(0, 100, getWidth(), getHeight());
        int x = serpiente.mostrarPuntos();
        String Convertir=String.valueOf(x);
        texto.setText("Puntaje: "+Convertir);
        
        serpiente.pintar(g);
        try {
            serpiente.mover(getWidth(), getHeight());
        } catch (InterruptedException ex) {
            Logger.getLogger(MiPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public Dimension getPreferredSize(){
        return new Dimension(1000,700);
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //System.out.println("Typed: " + e.getKeyCode() + " Char: " + e.getKeyChar());
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Pressed: " + e.getKeyCode() + " Char: " + e.getKeyChar());
        serpiente.cambioDir(e.getKeyCode());
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Released: " + e.getKeyCode() + " Char: " + e.getKeyChar());
    }
}
