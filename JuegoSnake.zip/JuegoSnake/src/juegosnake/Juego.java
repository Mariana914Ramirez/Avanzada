/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegosnake;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;
import javax.swing.JOptionPane;

/**
 *
 * @author BLUE_LIGHT
 */
public class Juego {
    
    private Bola manzana;
    private LinkedList<Bola> snake;
    private int dir;
    private boolean manzanaCuerpo=true;
    int numeros=0;
    
    public Juego(){
        snake = new LinkedList<>();
        config();
    }

    public void pintar(Graphics g) {
        manzana.Pintar(g);
        for(Bola bola : snake){
            bola.Pintar(g);
        }
    }

    public void mover(int ancho, int alto) throws InterruptedException {
        Bola cabezaAnt = snake.getFirst();

        if(cabezaAnt.getX()<0)
        {
            cabezaAnt.setX(ancho-40);
        } else if(cabezaAnt.getX()>ancho-20)
        {
            cabezaAnt.setX(0);
        }
        
        
        
        if(manzana.getY()<=140&&manzana.getX()==cabezaAnt.getX())
        {
            if(cabezaAnt.getY()<100&&dir==2)
            {
                cabezaAnt.setY(alto-40);
            }
        }
        else
        {
            if(cabezaAnt.getY()<140&&dir==2)
            {
                cabezaAnt.setY(alto-40);
            }
        }
        
        
        if(cabezaAnt.getY()>alto-20)
        {
            cabezaAnt.setY(100);
        }

        for(int i=1; i<snake.size();i++){
            if(cabezaAnt.getX()==(snake.get(i)).getX() && cabezaAnt.getY()==(snake.get(i)).getY())
            {
                
                Thread.sleep(500);
                System.exit(0);
            }
        }
        
        
        if(cabezaAnt.getBounds().intersects(manzana.getBounds()))
        {
            numeros=numeros+10;
            int nX = ancho/cabezaAnt.TAM-1;
            int nY = (alto-100)/cabezaAnt.TAM-1;
            manzana.setX(((int)(Math.random()*nX))* cabezaAnt.TAM);
            manzana.setY((((int)(Math.random()*nY))* cabezaAnt.TAM)+100);
            while(manzanaCuerpo)
            {
                int verificar=0;
                for(int i=1; i<snake.size();i++){
                    if(manzana.getX()==(snake.get(i)).getX() && manzana.getY()==(snake.get(i)).getY())
                    {
                        nX = ancho/cabezaAnt.TAM-1;
                        nY = (alto-100)/cabezaAnt.TAM-1;
                        manzana.setX(((int)(Math.random()*nX))* cabezaAnt.TAM);
                        manzana.setY((((int)(Math.random()*nY))* cabezaAnt.TAM)+100);
                    }
                    else{verificar++;}
                }
                if(verificar==(snake.size())-1)
                {
                    manzanaCuerpo=false;
                }
            }
            manzanaCuerpo=true;
        } else if(dir>0)
        {
            snake.removeLast();
        }
        if(dir==1)
        {
            Bola nueva = new Bola(new Color(226,102,0), cabezaAnt.getX()-cabezaAnt.TAM,cabezaAnt.getY());
            cabezaAnt.setColor(Color.blue);
            snake.addFirst(nueva);
        }
        else if(dir==2)
        {
            Bola nueva = new Bola(new Color(226,102,0), cabezaAnt.getX(),cabezaAnt.getY()-cabezaAnt.TAM);
            cabezaAnt.setColor(Color.blue);
            snake.addFirst(nueva);
        }
        else if(dir==3)
        {
            Bola nueva = new Bola(new Color(226,102,0), cabezaAnt.getX()+cabezaAnt.TAM,cabezaAnt.getY());
            cabezaAnt.setColor(Color.blue);
            snake.addFirst(nueva);
        }
        else if(dir==4)
        {
            Bola nueva = new Bola(new Color(226,102,0), cabezaAnt.getX(),cabezaAnt.getY()+cabezaAnt.TAM);
            cabezaAnt.setColor(Color.blue);
            snake.addFirst(nueva);
        }
        
        
    }

    private void config() {
        manzana = new Bola(Color.red, 120, 100);
        snake.add(new Bola(new Color(226,102,0), 600, 420));
        snake.add(new Bola(Color.blue, 600, 460));
        snake.add(new Bola(Color.blue, 600, 500));
    }

    public void cambioDir(int keyCode) {
        if(keyCode>=37&&keyCode<=40)
        {
            dir=keyCode-36;
        }
    }
    
    public int mostrarPuntos()
    {
        return numeros;
    }
    
}
