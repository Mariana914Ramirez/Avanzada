/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shat.vistas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author BLUE_LIGHT
 */
public class Registro extends JFrame{
    
    private JButton Cancelar;
    private JButton Ingresar;
    private JLabel titulo;
    private JTextField correo;
    private JTextField nombre;
    private JTextField apellidos;
    private JTextField password;
    
    public Registro()
    {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Shat");
        this.getContentPane().setBackground(new Color(42,56,59));
        
        
        Ingresar=new JButton("Registrar");
        Ingresar.setBackground(new Color(86,244,66));
        Ingresar.setFont(new Font("Consolas", Font.BOLD, 20));
        Ingresar.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        
        titulo=new JLabel("Registro", JLabel.CENTER);
        titulo.setFont(new Font("Consolas", Font.BOLD, 20));
        titulo.setForeground(Color.white);
        
        correo=new JTextField("Correo");
        correo.setFont(new Font("Consolas", Font.BOLD, 20));
        correo.setSize(150, 100);
        correo.setLocation(0, 150);
        this.setLayout(null);
        
        nombre=new JTextField("Nombre");
        nombre.setFont(new Font("Consolas", Font.BOLD, 20));
        nombre.setSize(150, 100);
        nombre.setLocation(0, 150);
        this.setLayout(null);
        
        apellidos=new JTextField("Apellidos");
        apellidos.setFont(new Font("Consolas", Font.BOLD, 20));
        apellidos.setSize(150, 100);
        apellidos.setLocation(0, 150);
        this.setLayout(null);
        
        password=new JTextField("Password");
        password.setFont(new Font("Consolas", Font.BOLD, 20));
        password.setSize(150, 100);
        password.setLocation(0, 300);
        this.setLayout(null);
        
        
        GroupLayout datos=new GroupLayout(this.getContentPane());
        
        datos.setHorizontalGroup(
                datos.createParallelGroup()
                    .addComponent(titulo, 80, 400, 1200)
                    .addComponent(correo, 80, 80, 1200)
                    .addComponent(nombre, 80, 80, 1200)
                    .addComponent(apellidos, 80, 80, 1200)
                    .addComponent(password, 80, 80, 1200)
                    .addComponent(Ingresar, 80, 80, 1200)
                                                           
        );
        
        
        datos.setVerticalGroup(
                datos.createSequentialGroup()
                    .addComponent(titulo, 10, 40, 80)
                    .addComponent(correo, 10, 40, 80)
                    .addComponent(nombre, 10, 40, 80)
                    .addComponent(apellidos, 10, 40, 80)
                    .addComponent(password, 10, 40, 80)
                    .addComponent(Ingresar, 10, 40, 80)
                                                           
        );
        datos.setAutoCreateContainerGaps(true);
        datos.setAutoCreateGaps(true);
        setLayout(datos);
        pack();
    }
    
}
